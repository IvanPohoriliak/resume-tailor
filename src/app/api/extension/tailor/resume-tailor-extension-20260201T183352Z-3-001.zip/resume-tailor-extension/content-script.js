(function() {
  console.log('Resume Tailor: Bulletproof mode activated');

  // Пошук кнопки Apply (множинні методи)
  const findApplyButton = () => {
    // Спробуємо різні селектори
    const selectors = [
      'button.jobs-apply-button',
      'button[aria-label*="Easy Apply"]',
      'button[aria-label*="Apply"]'
    ];
    
    for (const selector of selectors) {
      const btn = document.querySelector(selector);
      if (btn) return btn;
    }

    // Якщо не знайшли - шукаємо за текстом у всіх кнопках
    return Array.from(document.querySelectorAll('button')).find(b => 
      /Easy Apply|Apply now|Apply/i.test(b.innerText || b.textContent)
    );
  };

  const injectButton = () => {
    if (document.getElementById('rt-tailor-btn')) return;

    const applyBtn = findApplyButton();
    if (!applyBtn) return;

    const tailorBtn = document.createElement('button');
    tailorBtn.id = 'rt-tailor-btn';
    tailorBtn.innerHTML = '✨ Tailor Resume';
    
    // Inline styles - без залежності від CSS файлів
    Object.assign(tailorBtn.style, {
      marginLeft: '8px',
      padding: '10px 16px',
      backgroundColor: '#764ba2',
      color: 'white',
      border: 'none',
      borderRadius: '20px',
      fontWeight: '600',
      cursor: 'pointer',
      fontSize: '14px',
      zIndex: '9999'
    });

    tailorBtn.onclick = () => {
      tailorBtn.innerText = '⏳ Processing...';
      tailorBtn.disabled = true;
      
      const jobData = {
        title: document.querySelector('.job-details-jobs-unified-top-card__job-title')?.innerText?.trim() || '',
        company: document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText?.trim() || '',
        description: document.querySelector('#job-details')?.innerText?.trim() || 
                     document.querySelector('.jobs-description-content__text')?.innerText?.trim() || '',
        url: window.location.href
      };
      
      chrome.runtime.sendMessage({ action: 'TAILOR_RESUME', jobData }, (response) => {
        if (chrome.runtime.lastError) {
          tailorBtn.innerText = '❌ Error';
          console.error('RT Error:', chrome.runtime.lastError);
        } else if (response?.error) {
          tailorBtn.innerText = '❌ Error';
          console.error('RT Error:', response.error);
        } else {
          tailorBtn.innerText = '✅ Done';
        }
        
        setTimeout(() => {
          tailorBtn.innerHTML = '✨ Tailor Resume';
          tailorBtn.disabled = false;
        }, 3000);
      });
    };

    applyBtn.parentElement.appendChild(tailorBtn);
    console.log('Resume Tailor button injected');
  };

  // Агресивний MutationObserver - реагує на будь-які зміни DOM
  const observer = new MutationObserver(() => {
    injectButton();
  });

  observer.observe(document.body, { childList: true, subtree: true });
  
  // Initial attempt
  setTimeout(injectButton, 1000);
})();
