// Popup logic

document.addEventListener('DOMContentLoaded', async () => {
  await checkAuthAndLoadData();

  // Button handlers
  document.getElementById('login-btn').onclick = handleLogin;
  document.getElementById('signup-btn').onclick = handleSignup;
  document.getElementById('logout-btn').onclick = handleLogout;
  document.getElementById('dashboard-btn').onclick = openDashboard;

  // Listen for auth updates
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'AUTH_SUCCESS') {
      checkAuthAndLoadData();
    }
  });
});

// Check authentication and load data
async function checkAuthAndLoadData() {
  const loading = document.getElementById('loading');
  const loginState = document.getElementById('login-state');
  const authState = document.getElementById('authenticated-state');

  loading.style.display = 'block';
  loginState.style.display = 'none';
  authState.style.display = 'none';

  try {
    // Check if user is authenticated
    const token = await getAuthToken();
    
    if (!token) {
      // Not authenticated
      loading.style.display = 'none';
      loginState.style.display = 'block';
      return;
    }

    // Load user data
    await loadUserData();

    loading.style.display = 'none';
    authState.style.display = 'block';

  } catch (error) {
    console.error('Error loading data:', error);
    loading.style.display = 'none';
    loginState.style.display = 'block';
  }
}

// Load user's recent applications and stats
async function loadUserData() {
  // Get saved jobs from backend
  chrome.runtime.sendMessage({ action: 'GET_SAVED_JOBS' }, (response) => {
    if (response.error) {
      console.error('Error loading jobs:', response.error);
      return;
    }

    const jobs = response.jobs || [];
    displayJobs(jobs);
    updateStats(jobs);
  });
}

// Display jobs in the list
function displayJobs(jobs) {
  const jobList = document.getElementById('job-list');
  
  if (jobs.length === 0) {
    jobList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📄</div>
        <div>No applications yet</div>
        <div style="font-size: 12px; margin-top: 4px;">Visit a job page and click "Tailor Resume"</div>
      </div>
    `;
    return;
  }

  // Show most recent 5 jobs
  const recentJobs = jobs.slice(0, 5);
  
  jobList.innerHTML = recentJobs.map(job => {
    const scoreClass = job.ats_score >= 80 ? 'score-high' : 
                       job.ats_score >= 60 ? 'score-medium' : 'score-low';
    
    return `
      <div class="job-item" data-id="${job.id}">
        <div class="job-title">${truncate(job.job_metadata?.role || job.title, 35)}</div>
        <div class="job-company">${truncate(job.job_metadata?.company || job.company, 30)}</div>
        ${job.ats_score ? `<div class="job-score ${scoreClass}">ATS: ${job.ats_score}%</div>` : ''}
      </div>
    `;
  }).join('');

  // Add click handlers
  document.querySelectorAll('.job-item').forEach(item => {
    item.onclick = () => {
      const jobId = item.dataset.id;
      chrome.tabs.create({ 
        url: `https://resume-tailor-dun.vercel.app/refine?id=${jobId}` 
      });
    };
  });
}

// Update stats
function updateStats(jobs) {
  const total = jobs.length;
  const interviews = jobs.filter(j => j.status === 'interview').length;
  
  // Calculate average ATS score
  const scoresSum = jobs
    .filter(j => j.ats_score)
    .reduce((sum, j) => sum + j.ats_score, 0);
  const avgScore = jobs.length > 0 ? Math.round(scoresSum / jobs.length) : 0;

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-interview').textContent = interviews;
  document.getElementById('stat-score').textContent = avgScore || '--';
}

// Handle login
function handleLogin() {
  chrome.runtime.sendMessage({ action: 'OPEN_AUTH' });
  window.close();
}

// Handle signup
function handleSignup() {
  chrome.tabs.create({ url: 'https://resume-tailor-dun.vercel.app/signup' });
  window.close();
}

// Handle logout
async function handleLogout() {
  if (confirm('Are you sure you want to log out?')) {
    await clearAuth();
    checkAuthAndLoadData();
  }
}

// Open dashboard
function openDashboard() {
  chrome.tabs.create({ url: 'https://resume-tailor-dun.vercel.app/dashboard' });
}

// Helper: Get auth token
async function getAuthToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['resume_tailor_auth_token', 'resume_tailor_token_expiry'], (result) => {
      const token = result.resume_tailor_auth_token;
      const expiry = result.resume_tailor_token_expiry;

      if (!token) {
        resolve(null);
        return;
      }

      if (expiry && Date.now() > expiry) {
        clearAuth();
        resolve(null);
        return;
      }

      resolve(token);
    });
  });
}

// Helper: Clear auth
async function clearAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(
      ['resume_tailor_auth_token', 'resume_tailor_token_expiry'],
      resolve
    );
  });
}

// Helper: Truncate text
function truncate(text, maxLength) {
  if (!text) return '';
  return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
}
