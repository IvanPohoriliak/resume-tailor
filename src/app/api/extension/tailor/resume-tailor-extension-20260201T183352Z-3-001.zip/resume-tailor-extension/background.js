// Background Service Worker
// Handles API communication and message passing

console.log('Resume Tailor background worker started');

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received:', message.action);

  switch (message.action) {
    case 'TAILOR_RESUME':
      handleTailorResume(message.jobData, sendResponse);
      return true; // Will respond asynchronously

    case 'OPEN_AUTH':
      handleOpenAuth();
      break;

    case 'GET_RESUMES':
      handleGetResumes(sendResponse);
      return true;

    case 'GET_SAVED_JOBS':
      handleGetSavedJobs(sendResponse);
      return true;

    case 'SAVE_JOB':
      handleSaveJob(message.jobData, sendResponse);
      return true;

    default:
      console.log('Unknown action:', message.action);
  }
});

// Handle tailor resume request
async function handleTailorResume(jobData, sendResponse) {
  try {
    console.log('Tailoring resume for:', jobData.title);

    // Get auth token
    const token = await getAuthToken();
    if (!token) {
      sendResponse({ error: 'Not authenticated' });
      return;
    }

    // Call API
    const response = await fetch('https://resume-tailor-dun.vercel.app/api/extension/tailor', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Extension-Version': chrome.runtime.getManifest().version
      },
      body: JSON.stringify({ jobData })
    });

    if (response.status === 401) {
      await clearAuth();
      sendResponse({ error: 'Session expired. Please log in again.' });
      return;
    }

    if (response.status === 429) {
      sendResponse({ error: 'Rate limit exceeded. Please try again in a few minutes.' });
      return;
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }));
      sendResponse({ error: error.error || 'Failed to tailor resume' });
      return;
    }

    const data = await response.json();
    console.log('Resume tailored successfully');

    sendResponse({
      success: true,
      applicationId: data.applicationId,
      atsScore: data.atsScore,
      downloadUrl: data.downloadUrl,
      missingKeywords: data.missingKeywords
    });

  } catch (error) {
    console.error('Tailor resume error:', error);
    sendResponse({ error: 'Network error. Please check your connection.' });
  }
}

// Open authentication page
function handleOpenAuth() {
  const authUrl = 'https://resume-tailor-dun.vercel.app/extension-auth';
  chrome.tabs.create({ url: authUrl });
}

// Get user's resumes
async function handleGetResumes(sendResponse) {
  try {
    const token = await getAuthToken();
    if (!token) {
      sendResponse({ error: 'Not authenticated', resumes: [] });
      return;
    }

    const response = await fetch('https://resume-tailor-dun.vercel.app/api/extension/resumes', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Extension-Version': chrome.runtime.getManifest().version
      }
    });

    if (!response.ok) {
      sendResponse({ error: 'Failed to load resumes', resumes: [] });
      return;
    }

    const data = await response.json();
    sendResponse({ resumes: data.resumes || [] });

  } catch (error) {
    console.error('Get resumes error:', error);
    sendResponse({ error: 'Network error', resumes: [] });
  }
}

// Get saved jobs
async function handleGetSavedJobs(sendResponse) {
  try {
    const token = await getAuthToken();
    if (!token) {
      sendResponse({ error: 'Not authenticated', jobs: [] });
      return;
    }

    const response = await fetch('https://resume-tailor-dun.vercel.app/api/extension/jobs', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Extension-Version': chrome.runtime.getManifest().version
      }
    });

    if (!response.ok) {
      sendResponse({ error: 'Failed to load jobs', jobs: [] });
      return;
    }

    const data = await response.json();
    sendResponse({ jobs: data.jobs || [] });

  } catch (error) {
    console.error('Get saved jobs error:', error);
    sendResponse({ error: 'Network error', jobs: [] });
  }
}

// Save job for later
async function handleSaveJob(jobData, sendResponse) {
  try {
    const token = await getAuthToken();
    if (!token) {
      sendResponse({ error: 'Not authenticated' });
      return;
    }

    const response = await fetch('https://resume-tailor-dun.vercel.app/api/extension/save-job', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Extension-Version': chrome.runtime.getManifest().version
      },
      body: JSON.stringify({ jobData })
    });

    if (!response.ok) {
      sendResponse({ error: 'Failed to save job' });
      return;
    }

    const data = await response.json();
    sendResponse({ success: true, jobId: data.jobId });

  } catch (error) {
    console.error('Save job error:', error);
    sendResponse({ error: 'Network error' });
  }
}

// Auth helper functions
async function getAuthToken() {
  const result = await chrome.storage.local.get(['resume_tailor_auth_token', 'resume_tailor_token_expiry']);
  const token = result.resume_tailor_auth_token;
  const expiry = result.resume_tailor_token_expiry;

  if (!token) return null;
  if (expiry && Date.now() > expiry) {
    await clearAuth();
    return null;
  }

  return token;
}

async function clearAuth() {
  await chrome.storage.local.remove(['resume_tailor_auth_token', 'resume_tailor_token_expiry']);
}

// Extension installed/updated
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Extension installed');
    // Open welcome page
    chrome.tabs.create({ url: 'https://resume-tailor-dun.vercel.app/welcome' });
  } else if (details.reason === 'update') {
    console.log('Extension updated to', chrome.runtime.getManifest().version);
  }
});
