// Auth Listener - Runs on extension-auth page
// Captures auth token from page and saves to storage

console.log('Resume Tailor: Auth listener active');

// Listen for postMessage from the page
window.addEventListener('message', async (event) => {
  // Verify origin
  if (event.origin !== 'https://resume-tailor-dun.vercel.app') {
    return;
  }

  console.log('Message received:', event.data);

  // Handle auth token
  if (event.data.type === 'RESUME_TAILOR_AUTH' && event.data.token) {
    const token = event.data.token;
    const expiryDays = 7;
    const expiry = Date.now() + (expiryDays * 24 * 60 * 60 * 1000);

    try {
      await chrome.storage.local.set({
        resume_tailor_auth_token: token,
        resume_tailor_token_expiry: expiry
      });

      console.log('✅ Token saved successfully!');
      
      // Notify background worker
      chrome.runtime.sendMessage({ action: 'AUTH_SUCCESS' });
    } catch (error) {
      console.error('❌ Error saving token:', error);
    }
  }
});

console.log('Auth listener ready');
