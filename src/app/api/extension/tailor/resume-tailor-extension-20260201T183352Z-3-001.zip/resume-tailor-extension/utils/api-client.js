// API Client for Resume Tailor Extension
// Handles all communication with backend

const API_BASE_URL = 'https://resume-tailor-dun.vercel.app';
const EXTENSION_VERSION = chrome.runtime.getManifest().version;

// Make authenticated API request
async function makeAPIRequest(endpoint, options = {}) {
  const token = await getAuthToken();
  
  if (!token) {
    throw new Error('Not authenticated');
  }

  const url = `${API_BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
    'X-Extension-Version': EXTENSION_VERSION,
    ...options.headers
  };

  try {
    const response = await fetch(url, {
      ...options,
      headers
    });

    // Handle authentication errors
    if (response.status === 401) {
      await clearAuth();
      throw new Error('Authentication expired. Please log in again.');
    }

    // Handle rate limiting
    if (response.status === 429) {
      throw new Error('Too many requests. Please try again later.');
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(error.error || 'Request failed');
    }

    return await response.json();
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
}

// Tailor resume for a job
async function tailorResume(jobData, resumeId = null) {
  return makeAPIRequest('/api/extension/tailor', {
    method: 'POST',
    body: JSON.stringify({
      jobData: sanitizeJobData(jobData),
      resumeId
    })
  });
}

// Get user's resumes
async function getUserResumes() {
  return makeAPIRequest('/api/extension/resumes', {
    method: 'GET'
  });
}

// Save job for later
async function saveJob(jobData) {
  return makeAPIRequest('/api/extension/save-job', {
    method: 'POST',
    body: JSON.stringify({
      jobData: sanitizeJobData(jobData)
    })
  });
}

// Get saved jobs
async function getSavedJobs() {
  return makeAPIRequest('/api/extension/jobs', {
    method: 'GET'
  });
}

// Sanitize job data before sending to API (XSS prevention)
function sanitizeJobData(jobData) {
  const sanitizeText = (text) => {
    if (!text) return '';
    return text
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove scripts
      .replace(/<[^>]+>/g, '') // Remove HTML tags
      .trim()
      .substring(0, 10000); // Limit length
  };

  const validateUrl = (url) => {
    try {
      const parsed = new URL(url);
      const allowedDomains = ['linkedin.com', 'indeed.com'];
      if (allowedDomains.some(d => parsed.hostname.includes(d))) {
        return url;
      }
    } catch (e) {
      console.error('Invalid URL:', url);
    }
    return null;
  };

  return {
    title: sanitizeText(jobData.title),
    company: sanitizeText(jobData.company),
    description: sanitizeText(jobData.description),
    location: sanitizeText(jobData.location),
    salary: sanitizeText(jobData.salary),
    url: validateUrl(jobData.url)
  };
}

// Export functions for use in other files
if (typeof window !== 'undefined') {
  window.ResumeTailorAPI = {
    tailorResume,
    getUserResumes,
    saveJob,
    getSavedJobs
  };
}
