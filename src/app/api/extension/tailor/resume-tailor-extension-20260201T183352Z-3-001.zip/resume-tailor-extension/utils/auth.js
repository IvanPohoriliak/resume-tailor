// Token management with security best practices

const AUTH_TOKEN_KEY = 'resume_tailor_auth_token';
const TOKEN_EXPIRY_KEY = 'resume_tailor_token_expiry';

// Get authentication token
async function getAuthToken() {
  try {
    const result = await chrome.storage.local.get([AUTH_TOKEN_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[AUTH_TOKEN_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];

    if (!token) {
      return null;
    }

    // Check if token expired
    if (expiry && Date.now() > expiry) {
      await clearAuth();
      return null;
    }

    return token;
  } catch (error) {
    console.error('Error getting auth token:', error);
    return null;
  }
}

// Save authentication token
async function saveAuthToken(token, expiresInDays = 7) {
  try {
    const expiry = Date.now() + (expiresInDays * 24 * 60 * 60 * 1000);
    await chrome.storage.local.set({
      [AUTH_TOKEN_KEY]: token,
      [TOKEN_EXPIRY_KEY]: expiry
    });
    return true;
  } catch (error) {
    console.error('Error saving auth token:', error);
    return false;
  }
}

// Clear authentication
async function clearAuth() {
  try {
    await chrome.storage.local.remove([AUTH_TOKEN_KEY, TOKEN_EXPIRY_KEY]);
    return true;
  } catch (error) {
    console.error('Error clearing auth:', error);
    return false;
  }
}

// Check if user is authenticated
async function isAuthenticated() {
  const token = await getAuthToken();
  return !!token;
}

// Listen for auth messages from web pages (OAuth flow)
if (typeof window !== 'undefined') {
  window.addEventListener('message', async (event) => {
    // Verify origin for security
    if (event.origin !== 'https://resume-tailor-dun.vercel.app') {
      return;
    }

    // Handle auth token from OAuth flow
    if (event.data.type === 'RESUME_TAILOR_AUTH' && event.data.token) {
      await saveAuthToken(event.data.token);
      console.log('Authentication successful');
      
      // Notify extension popup to refresh
      chrome.runtime.sendMessage({ action: 'AUTH_SUCCESS' });
    }
  });
}
